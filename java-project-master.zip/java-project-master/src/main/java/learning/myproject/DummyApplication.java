package simplilearn.dummy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DummyApplication {

    public static void main(String args[]) {
    while (true) {
      System.out.println("Hello World");
    }
  }
}
